<?php
$host = "localhost"; // Change if needed
$username = "licfree_links";  // Your DB username
$password = "].!A}7juXn94";      // Your DB password
$database = "licfree_links";

$conn = new mysqli($host, $username, $password, $database);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>
