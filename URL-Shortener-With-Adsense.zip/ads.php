<?php
$original_url = $_GET['url'];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Advertisement | Preparing Your Content...</title>

    <!-- SEO Keywords for High CPC Ads -->
    <meta name="keywords" content="insurance, mortgage, loans, credit cards, web hosting, cloud storage, finance">
    <meta name="description" content="Please wait while we prepare your secure link. Get premium offers on loans, credit cards, and online services.">

    <!-- Google AdSense -->
    <script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-4452711820150477" crossorigin="anonymous"></script>

    <style>
        body {
            font-family: Arial, sans-serif;
            text-align: center;
            background-color: #f4f4f4;
            margin: 0;
            padding: 20px;
        }
        .container {
            background: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.2);
            max-width: 600px;
            margin: auto;
            position: relative;
        }
        h1 {
            color: #333;
        }
        .countdown {
            font-size: 24px;
            font-weight: bold;
            color: #ff4500;
        }
        .continue-btn {
            display: none;
            background: #28a745;
            color: white;
            text-decoration: none;
            padding: 12px 20px;
            font-size: 18px;
            border-radius: 5px;
            margin-top: 20px;
        }
        .ad-container {
            margin: 20px 0;
        }
        .loading-animation {
            font-size: 20px;
            font-weight: bold;
            color: #333;
            margin-top: 10px;
            animation: blink 1.5s infinite;
        }
        @keyframes blink {
            0% { opacity: 1; }
            50% { opacity: 0.5; }
            100% { opacity: 1; }
        }
        /* Game Styles */
        .game-container {
            position: relative;
            height: 250px;
            background: #fff3cd;
            border-radius: 10px;
            overflow: hidden;
            margin-top: 20px;
        }
        .star {
            width: 30px;
            height: 30px;
            background: gold;
            position: absolute;
            top: -40px;
            left: 50%;
            transform: translateX(-50%);
            border-radius: 50%;
            cursor: pointer;
            animation: fall linear infinite;
        }
        @keyframes fall {
            from {
                top: -40px;
            }
            to {
                top: 100%;
            }
        }
    </style>
</head>
<body>

<div class="container">
    <h1>Preparing Your Secure Link...</h1>
    
    <!-- Animated Loading Text -->
    <p class="loading-animation">Your content is being prepared, please wait...</p>

    <!-- Ad Below Header -->
    <div class="ad-container">
        <ins class="adsbygoogle"
            style="display:block"
            data-ad-client="ca-pub-4452711820150477"
            data-ad-slot="1234567890"
            data-ad-format="auto"
            data-full-width-responsive="true"></ins>
        <script>
            (adsbygoogle = window.adsbygoogle || []).push({});
        </script>
    </div>

    <p>Redirecting in <span class="countdown">12</span> seconds...</p>

    <!-- Mini Game: Catch the Falling Stars -->
    <div class="game-container">
        <p><b>Tap the Falling Stars to Reduce Wait Time!</b></p>
        <p>Score: <span id="score">0</span></p>
    </div>

    <!-- Ad Below Game -->
    <div class="ad-container">
        <ins class="adsbygoogle"
            style="display:block"
            data-ad-client="ca-pub-4452711820150477"
            data-ad-slot="0987654321"
            data-ad-format="auto"
            data-full-width-responsive="true"></ins>
        <script>
            (adsbygoogle = window.adsbygoogle || []).push({});
        </script>
    </div>

    <a href="<?= $original_url ?>" class="continue-btn">Click to Continue</a>
    
    <!-- Ad in Footer -->
    <div class="ad-container">
        <ins class="adsbygoogle"
            style="display:block"
            data-ad-client="ca-pub-4452711820150477"
            data-ad-slot="1122334455"
            data-ad-format="auto"
            data-full-width-responsive="true"></ins>
        <script>
            (adsbygoogle = window.adsbygoogle || []).push({});
        </script>
    </div>
</div>

<script>
    let timeLeft = 12;
    let score = 0;
    const countdownElement = document.querySelector(".countdown");
    const continueBtn = document.querySelector(".continue-btn");
    const gameContainer = document.querySelector(".game-container");
    const scoreElement = document.getElementById("score");

    function updateCountdown() {
        timeLeft--;
        countdownElement.textContent = timeLeft;
        if (timeLeft <= 0) {
            window.location.href = "<?= $original_url ?>";
            continueBtn.style.display = "inline-block";
        }
    }
    setInterval(updateCountdown, 1000);

    function createStar() {
        const star = document.createElement("div");
        star.classList.add("star");
        star.style.left = Math.random() * 90 + "%";
        gameContainer.appendChild(star);

        // Animate fall
        star.style.animationDuration = Math.random() * 2 + 2 + "s";

        star.addEventListener("click", function() {
            score++;
            scoreElement.textContent = score;
            timeLeft -= 1; // Reduce time for each catch
            if (timeLeft < 0) timeLeft = 0;
            star.remove();
        });

        setTimeout(() => star.remove(), 3000);
    }
    setInterval(createStar, 1000);
</script>

</body>
</html>
