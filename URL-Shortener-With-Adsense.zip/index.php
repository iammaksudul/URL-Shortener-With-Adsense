<?php
include 'db.php';

if ($_SERVER['REQUEST_METHOD'] == "POST") {
    $original_url = trim($_POST['url']);
    
    if (filter_var($original_url, FILTER_VALIDATE_URL)) {
        $short_code = substr(md5(time()), 0, 6);

        $stmt = $conn->prepare("INSERT INTO urls (short_code, original_url) VALUES (?, ?)");
        $stmt->bind_param("ss", $short_code, $original_url);
        $stmt->execute();
        
        $short_url = "https://tools.licfree.com/link/$short_code"; // Change domain if needed
    } else {
        $error = "Invalid URL! Please enter a valid link.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>URL Shortener - Make Your Links Short</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600&display=swap" rel="stylesheet">
    
    <!-- Your Google AdSense Code -->
    <script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-4452711820150477" crossorigin="anonymous"></script>

    <style>
        body {
            font-family: 'Poppins', sans-serif;
            background-color: #f4f4f4;
            text-align: center;
            padding: 20px;
        }
        .container {
            background: white;
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.1);
            max-width: 500px;
            margin: auto;
        }
        h1 {
            color: #333;
        }
        input[type="text"] {
            width: 80%;
            padding: 12px;
            border: 1px solid #ccc;
            border-radius: 5px;
            margin-top: 10px;
            font-size: 16px;
        }
        button {
            background-color: #007bff;
            color: white;
            border: none;
            padding: 12px 18px;
            font-size: 16px;
            border-radius: 5px;
            cursor: pointer;
            transition: 0.3s;
        }
        button:hover {
            background-color: #0056b3;
        }
        .short-url-container {
            margin-top: 15px;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .short-url {
            background-color: #e9ecef;
            padding: 12px;
            border-radius: 5px;
            font-size: 18px;
            flex-grow: 1;
            margin-right: 10px;
            overflow-x: auto;
        }
        .copy-btn {
            background-color: #28a745;
            padding: 10px;
            font-size: 16px;
            border: none;
            color: white;
            cursor: pointer;
            border-radius: 5px;
        }
        .copy-btn:hover {
            background-color: #218838;
        }
        .error {
            color: red;
            margin-top: 10px;
        }
        .footer {
            margin-top: 30px;
            font-size: 14px;
            color: #666;
        }
        .ad-container {
            margin: 20px auto;
            max-width: 500px;
            text-align: center;
        }
    </style>
</head>
<body>

    <div class="container">
        <h1>🔗 Shorten Your URL</h1>
        <p>Enter a long URL to make it shorter.</p>

        <!-- AdSense Ad Below Header -->
        <div class="ad-container">
            <ins class="adsbygoogle"
                style="display:block"
                data-ad-client="ca-pub-4452711820150477"
                data-ad-slot="1234567890"
                data-ad-format="auto"
                data-full-width-responsive="true"></ins>
            <script>
                (adsbygoogle = window.adsbygoogle || []).push({});
            </script>
        </div>

        <form method="POST">
            <input type="text" name="url" placeholder="Enter your URL" required>
            <br><br>
            <button type="submit">Shorten</button>
        </form>

        <!-- AdSense Ad Below Form -->
        <div class="ad-container">
            <ins class="adsbygoogle"
                style="display:block"
                data-ad-client="ca-pub-4452711820150477"
                data-ad-slot="0987654321"
                data-ad-format="auto"
                data-full-width-responsive="true"></ins>
            <script>
                (adsbygoogle = window.adsbygoogle || []).push({});
            </script>
        </div>

        <?php if (isset($short_url)): ?>
            <div class="short-url-container">
                <input type="text" id="shortUrl" class="short-url" value="<?= $short_url ?>" readonly>
                <button class="copy-btn" onclick="copyShortUrl()">Copy</button>
            </div>
        <?php endif; ?>

        <?php if (isset($error)): ?>
            <p class="error"><?= $error ?></p>
        <?php endif; ?>
    </div>

    <!-- AdSense Ad in Footer -->
    <div class="footer">
        &copy; <?= date('Y'); ?> URL Shortener | Powered by LicFree
        <br>
        <div class="ad-container">
            <ins class="adsbygoogle"
                style="display:block"
                data-ad-client="ca-pub-4452711820150477"
                data-ad-slot="1122334455"
                data-ad-format="auto"
                data-full-width-responsive="true"></ins>
            <script>
                (adsbygoogle = window.adsbygoogle || []).push({});
            </script>
        </div>
    </div>

    <script>
        function copyShortUrl() {
            var copyText = document.getElementById("shortUrl");
            copyText.select();
            copyText.setSelectionRange(0, 99999);
            document.execCommand("copy");
            alert("Copied: " + copyText.value);
        }
    </script>

</body>
</html>
